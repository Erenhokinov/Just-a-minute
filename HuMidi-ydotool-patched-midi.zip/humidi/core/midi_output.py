"""
Virtual MIDI keyboard output — alternative to core/ydotool_keyboard.py.

Instead of pressing QWERTY keys, this creates a virtual MIDI *output* port
(on Linux: an ALSA-sequencer port) named "HuMidi Virtual Keyboard" and sends
real note_on / note_off / sustain-pedal (CC64) messages to it. Connect that
port to any synth or DAW (FluidSynth, Pianoteq, Carla, Ardour, ...) and it
behaves like a plugged-in 88-key MIDI keyboard.

MidiKeyboard is duck-typed to the small slice of the Controller API that
core/player.py uses, so the player's press/release logic stays unchanged:

  - press('#60') / release('#60')   -> note_on / note_off for MIDI note 60.
                                       ('#<n>' is what MidiKeyMapper emits.)
  - press(Key.space) / release(...) -> sustain pedal down / up (CC64 127 / 0).
                                       Recognised by the sentinel's .name, so
                                       this module doesn't import evdev.
  - press/release(Key.shift|ctrl|alt) -> ignored (no meaning for MIDI).
  - set_velocity(v)                 -> velocity for the NEXT note_on. This is
                                       the MIDI counterpart of the Alt+key
                                       "velocity shortcut" used on the QWERTY
                                       backend, but with the full 1-127 range.
  - pressed(*keys) / batch()        -> context managers, kept for API parity.

Needs the `python-rtmidi` package (mido's rtmidi backend). On NixOS:
`nixpkgs#python3Packages.python-rtmidi`.

PianoRoomsKeyboard (bottom of this file) is a second backend with the same
interface, for the Roblox game "Piano Rooms", which has its own "MIDI Connect"
input. That game can't read a MIDI port either; it reads a fixed sequence of
numpad key presses per MIDI message (see the class docstring). So
PianoRoomsKeyboard gives the game real note on/off, velocity and sustain
through an emulated physical keyboard (/dev/uinput), no MIDI port involved.

The port is process-wide (get_shared_keyboard): HuMidi creates a new Player
for every playback, and if each one opened its own port you would have to
reconnect your synth every time. One port, opened once, reused by all.
"""

import atexit
import threading
import time
from contextlib import contextmanager

DEFAULT_PORT_NAME = "HuMidi Virtual Keyboard"
DEFAULT_VELOCITY = 100

_CC_SUSTAIN = 64
_CC_ALL_NOTES_OFF = 123


class MidiKeyboard:
    def __init__(self, port_name: str = DEFAULT_PORT_NAME, channel: int = 0, **options):
        self.port_name = port_name
        self.channel = channel
        self._open(port_name, **options)
        self._lock = threading.Lock()
        self._sounding: set = set()
        self._pedal_down = False
        self._velocity = DEFAULT_VELOCITY

    def _open(self, port_name: str, **options) -> None:
        try:
            import mido
            backend = mido.Backend("mido.backends.rtmidi", load=True)
            self._mido = mido
            self._port = backend.open_output(port_name, virtual=True)
        except ImportError as exc:
            raise RuntimeError(
                "midi_output: python-rtmidi is not installed, so mido has no "
                "rtmidi backend. Add it to your environment "
                "(NixOS: nixpkgs#python3Packages.python-rtmidi; "
                "pip: python-rtmidi)."
            ) from exc
        except Exception as exc:
            raise RuntimeError(
                f"midi_output: couldn't create the virtual MIDI port "
                f"{port_name!r} ({exc}). On Linux this needs ALSA sequencer "
                "support (the snd_seq kernel module)."
            ) from exc

    # ---- Controller-compatible surface --------------------------------

    def set_velocity(self, velocity: int) -> None:
        self._velocity = max(1, min(127, int(velocity)))

    def press(self, key) -> None:
        note = self._note_for(key)
        if note is not None:
            with self._lock:
                if note in self._sounding:
                    # Same note struck again while still held: release first so
                    # the synth gets a clean retrigger and the on/off counts
                    # stay balanced.
                    self._send("note_off", note=note, velocity=0)
                self._send("note_on", note=note, velocity=self._velocity)
                self._sounding.add(note)
        elif self._is_pedal(key):
            self._set_pedal(True)

    def release(self, key) -> None:
        note = self._note_for(key)
        if note is not None:
            with self._lock:
                if note in self._sounding:
                    self._send("note_off", note=note, velocity=0)
                    self._sounding.discard(note)
        elif self._is_pedal(key):
            self._set_pedal(False)

    @contextmanager
    def pressed(self, *keys):
        for k in keys:
            self.press(k)
        try:
            yield
        finally:
            for k in keys:
                self.release(k)

    @contextmanager
    def batch(self):
        # MIDI messages go out immediately; nothing to coalesce.
        yield

    # ---- MIDI-specific helpers ----------------------------------------

    def all_notes_off(self) -> None:
        """Release every note this object has sounded, plus the pedal."""
        with self._lock:
            for note in sorted(self._sounding):
                self._send("note_off", note=note, velocity=0)
            self._sounding.clear()
        self._set_pedal(False)

    def close(self) -> None:
        try:
            self.all_notes_off()
            with self._lock:
                self._send("control_change", control=_CC_ALL_NOTES_OFF, value=0)
        finally:
            self._close_port()

    # ---- internals ----------------------------------------------------

    def _send(self, msg_type: str, **kwargs) -> None:
        # Caller holds self._lock where state is touched; the port itself is
        # only ever written from here.
        self._port.send(self._mido.Message(msg_type, channel=self.channel, **kwargs))

    def _close_port(self) -> None:
        self._port.close()

    def _set_pedal(self, down: bool) -> None:
        with self._lock:
            if down == self._pedal_down:
                return
            self._pedal_down = down
            self._send("control_change", control=_CC_SUSTAIN, value=127 if down else 0)

    @staticmethod
    def _note_for(key):
        if isinstance(key, str) and key.startswith("#"):
            note = int(key[1:])
            if not 0 <= note <= 127:
                raise KeyError(f"midi_output: note {note} outside 0-127")
            return note
        return None

    @staticmethod
    def _is_pedal(key) -> bool:
        name = getattr(key, "name", None)
        if name == "space":
            return True
        if name in ("shift", "ctrl", "alt", "f6"):
            return False  # modifiers etc. — meaningless for MIDI, ignore
        raise KeyError(f"midi_output: don't know how to send {key!r} as MIDI")


class PianoRoomsKeyboard(MidiKeyboard):
    """MIDI for Piano Rooms' "MIDI Connect", delivered as numpad key presses.

    Wire format, as used by the MidiConnect program for that game: each MIDI
    message is the numpad `*` key followed by four numpad "digits" in base 12,
    where digit 0-9 = numpad 0-9, 10 = numpad `-`, 11 = numpad `+`:

        note_on   `*` [note // 12] [note % 12] [velocity // 12] [velocity % 12]
        note_off  `*` [note // 12] [note % 12] [0] [0]
        sustain   `*` [11] [11] [value // 12] [value % 12]
                  (sustain pedal is sent as "control 143", i.e. digits + +;
                   value is the usual CC64 value, 0-127)

    Each digit is a real key press+release on an emulated physical keyboard
    (a /dev/uinput device, same mechanism as ydotool_keyboard.py). Roblox
    ignores synthetic input that isn't from a registered keyboard device.

    Keep NumLock ON: the numpad keys have to arrive as numpad keys.

    Options (kwargs of get_shared_keyboard): key_delay - seconds to wait
    between two key events (default 0; raise it if the game drops digits).
    """

    _KEY_CODES = {  # linux/input-event-codes.h
        "*": 55,                                    # KEY_KPASTERISK
        0: 82, 1: 79, 2: 80, 3: 81, 4: 75,          # KEY_KP0..KP4
        5: 76, 6: 77, 7: 71, 8: 72, 9: 73,          # KEY_KP5..KP9
        10: 74,                                     # KEY_KPMINUS
        11: 78,                                     # KEY_KPPLUS
    }
    _SUSTAIN_CONTROL = 143

    def _open(self, port_name: str, key_delay: float = 0.0, **options) -> None:
        self._key_delay = key_delay
        try:
            from evdev import UInput, ecodes
            self._ecodes = ecodes
            self._ui = UInput(
                {ecodes.EV_KEY: sorted(self._KEY_CODES.values())},
                name="humidi-piano-rooms-keyboard",
            )
        except ImportError as exc:
            raise RuntimeError(
                "midi_output: python-evdev is not installed "
                "(NixOS: python3Packages.evdev)."
            ) from exc
        except (PermissionError, OSError) as exc:
            raise RuntimeError(
                f"midi_output: couldn't open /dev/uinput ({exc}). Make sure "
                "`hardware.uinput.enable = true;` is set and your user is in "
                "the 'uinput' group (relogin after rebuilding)."
            ) from exc

    def _send(self, msg_type: str, **kwargs) -> None:
        # Called with self._lock held (or from a path that holds it), so one
        # message's five key taps can never interleave with another's.
        if msg_type == "note_on":
            digits = self._digits(kwargs["note"], kwargs["velocity"])
        elif msg_type == "note_off":
            digits = self._digits(kwargs["note"], 0)
        elif msg_type == "control_change" and kwargs["control"] == _CC_SUSTAIN:
            digits = self._digits(self._SUSTAIN_CONTROL, kwargs["value"])
        else:
            return  # this protocol has nothing for other messages (e.g. CC123)
        for key in ["*"] + digits:
            self._tap(self._KEY_CODES[key])

    @staticmethod
    def _digits(number: int, value: int) -> list:
        return [number // 12, number % 12, value // 12, value % 12]

    def _tap(self, code: int) -> None:
        ec = self._ecodes
        self._ui.write(ec.EV_KEY, code, 1)
        self._ui.syn()
        self._ui.write(ec.EV_KEY, code, 0)
        self._ui.syn()
        if self._key_delay:
            time.sleep(self._key_delay)

    def _close_port(self) -> None:
        self._ui.close()


_BACKENDS = {"midi": MidiKeyboard, "piano_rooms": PianoRoomsKeyboard}
_shared: dict = {}
_shared_lock = threading.Lock()


def get_shared_keyboard(kind: str = "midi", port_name: str = DEFAULT_PORT_NAME,
                        channel: int = 0, **options) -> MidiKeyboard:
    """Return the process-wide backend of the given kind, creating it on first use.

    kind: 'midi' (virtual MIDI port) or 'piano_rooms' (numpad-key protocol).
    port_name and options only matter for the first call (that's when the
    port / uinput device is created). channel can change between calls.
    """
    with _shared_lock:
        kb = _shared.get(kind)
        if kb is None:
            kb = _BACKENDS[kind](port_name, channel, **options)
            _shared[kind] = kb
        else:
            kb.channel = channel
        return kb


def _close_shared() -> None:
    for kb in list(_shared.values()):
        try:
            kb.close()
        except Exception:
            pass


atexit.register(_close_shared)
