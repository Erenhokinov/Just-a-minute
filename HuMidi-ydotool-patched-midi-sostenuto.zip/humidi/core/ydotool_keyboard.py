"""
Direct-uinput drop-in replacement for pynput.keyboard.

Earlier version of this shim shelled out to the `ydotool` CLI for every
keystroke. That's fine for the occasional key, but on dense/fast MIDI
passages it means dozens of fork+exec calls per second — real CPU overhead
and timing drift, even after batching simultaneous chord-notes into one
call (sequential fast notes, e.g. trills, are each their own call and don't
benefit from that batching at all).

This version instead opens /dev/uinput directly (via python-evdev) once,
at startup, and creates one persistent virtual keyboard. Every press/release
after that is a plain in-process function call — no subprocess, no fork,
sub-millisecond overhead regardless of how fast notes come in.

Needs `hardware.uinput.enable = true;` in your NixOS config and your user
in the resulting "uinput" group (same setup already used for the mouse
project in this conversation — nothing extra to configure if that's done).

Implements just enough of the pynput.keyboard API surface that HuMidi's
core/player.py, core/core.py and core/translator.py rely on:
  - Key.space / Key.grave / Key.shift / Key.ctrl / Key.alt  (sentinels, compared by identity)
    (space = sustain pedal, grave = the ` key = sostenuto pedal)
  - Controller().press(key) / .release(key)
  - Controller().pressed(*modifiers)  (context manager)
  - Controller().batch()  (context manager — still useful: guarantees all
    keys of one simulated instant reach the kernel via a single SYN_REPORT,
    i.e. a truly atomic chord, not just "sent close together")

It intentionally does NOT implement pynput.keyboard.Listener — HuMidi's
global hotkey (managers/HotkeyManager.py) still imports the real pynput for
that, since it usually keeps working via XWayland. If global hotkeys don't
fire for you, just use the Play/Pause button in the window instead.
"""

from contextlib import contextmanager

from evdev import UInput, ecodes

# --- Linux evdev keycodes (linux/input-event-codes.h) -----------------
_CHAR_CODES = {
    '1': 2, '2': 3, '3': 4, '4': 5, '5': 6, '6': 7, '7': 8, '8': 9, '9': 10, '0': 11,
    'q': 16, 'w': 17, 'e': 18, 'r': 19, 't': 20, 'y': 21, 'u': 22, 'i': 23, 'o': 24, 'p': 25,
    'a': 30, 's': 31, 'd': 32, 'f': 33, 'g': 34, 'h': 35, 'j': 36, 'k': 37, 'l': 38,
    'z': 44, 'x': 45, 'c': 46, 'v': 47, 'b': 48, 'n': 49, 'm': 50,
    ' ': 57,
}


class _KeySentinel:
    """Identity-comparable stand-in for pynput's Key enum members."""
    __slots__ = ("name", "code")

    def __init__(self, name: str, code: int):
        self.name = name
        self.code = code

    def __repr__(self):
        return f"Key.{self.name}"


class Key:
    space = _KeySentinel("space", 57)
    shift = _KeySentinel("shift", 42)   # KEY_LEFTSHIFT
    ctrl = _KeySentinel("ctrl", 29)     # KEY_LEFTCTRL
    alt = _KeySentinel("alt", 56)       # KEY_LEFTALT
    grave = _KeySentinel("grave", 41)  # KEY_GRAVE, the ` key: sostenuto pedal
    f6 = _KeySentinel("f6", 64)         # unused for output; kept for API parity


def _code_for(key) -> int:
    if isinstance(key, _KeySentinel):
        return key.code
    if isinstance(key, str) and key in _CHAR_CODES:
        return _CHAR_CODES[key]
    raise KeyError(f"ydotool_keyboard: no evdev keycode mapped for {key!r}")


_ALL_CODES = sorted(set(_CHAR_CODES.values()) | {42, 29, 56, 57, 41})
_CAPABILITIES = {ecodes.EV_KEY: _ALL_CODES}


class Controller:
    """API-compatible subset of pynput.keyboard.Controller, backed by a
    persistent virtual uinput keyboard (no subprocess per keystroke)."""

    def __init__(self):
        try:
            self._ui = UInput(_CAPABILITIES, name="humidi-virtual-keyboard")
        except (PermissionError, OSError) as exc:
            raise RuntimeError(
                "ydotool_keyboard: couldn't open /dev/uinput "
                f"({exc}). Make sure `hardware.uinput.enable = true;` is "
                "set in your NixOS config and your user is in the "
                "resulting 'uinput' group (relogin after rebuilding)."
            ) from exc
        self._batch_depth = 0
        self._dirty = False

    def press(self, key):
        self._ui.write(ecodes.EV_KEY, _code_for(key), 1)
        self._after_write()

    def release(self, key):
        self._ui.write(ecodes.EV_KEY, _code_for(key), 0)
        self._after_write()

    def _after_write(self):
        if self._batch_depth > 0:
            self._dirty = True
        else:
            self._ui.syn()

    @contextmanager
    def pressed(self, *keys):
        for k in keys:
            self.press(k)
        try:
            yield
        finally:
            for k in keys:
                self.release(k)

    @contextmanager
    def batch(self):
        """Queue writes and flush them as one atomic SYN_REPORT on exit.
        Nested batch() calls only flush once, at the outermost exit."""
        self._batch_depth += 1
        try:
            yield
        finally:
            self._batch_depth -= 1
            if self._batch_depth == 0 and self._dirty:
                self._ui.syn()
                self._dirty = False

    def close(self):
        self._ui.close()
