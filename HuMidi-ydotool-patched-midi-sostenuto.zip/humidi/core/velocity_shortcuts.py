"""
Velocity shortcuts — the Alt+<key> convention several Roblox piano games use
to set the "volume" applied to the next note played, since a QWERTY key
can't physically be struck harder or softer like a real piano key.

Sending Alt+<shortcut key> right before the note's own key press tells the
game which of ~32 discrete velocity buckets this note falls into. Ported
directly from nanoMIDIPlayer's default velocityMap so it lines up with what
those games actually expect.
"""

import bisect

# threshold (MIDI velocity, 0-127) -> shortcut key char
VELOCITY_MAP = {
    0: '1', 4: '2', 8: '3', 12: '4', 16: '5', 20: '6', 24: '7', 28: '8',
    32: '9', 36: '0', 40: 'q', 44: 'w', 48: 'e', 52: 'r', 56: 't', 60: 'y',
    64: 'u', 68: 'i', 72: 'o', 76: 'p', 80: 'a', 84: 's', 88: 'd', 92: 'f',
    96: 'g', 100: 'h', 104: 'j', 108: 'k', 112: 'l', 116: 'z', 120: 'x', 124: 'c',
}

_THRESHOLDS = sorted(VELOCITY_MAP.keys())


def find_velocity_key(velocity: int) -> str:
    """Return the shortcut key for the bucket this velocity falls into."""
    idx = bisect.bisect_right(_THRESHOLDS, velocity) - 1
    idx = max(0, min(idx, len(_THRESHOLDS) - 1))
    return VELOCITY_MAP[_THRESHOLDS[idx]]
